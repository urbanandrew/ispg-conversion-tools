# ISPG Conversion Tools

## Installation Instructions

1. Double-click INSTALL.bat
2. Launch Revit 2025 or 2027
3. Look for 'ISPG' tab in the ribbon

## Troubleshooting

If the ISPG tab doesn't appear:
1. Go to Add-Ins > External Tools in Revit
2. Check for any error messages related to ISPG Conversion
3. Verify the files were copied to:
   - Revit 2025: %APPDATA%\Autodesk\Revit\Addins\2025
   - Revit 2027: %APPDATA%\Autodesk\Revit\Addins\2027

## What's Included

- Unit Numbering tool
- Unit Numbering QA/QC
- Unit Material Management
- Import/Export Units (Legacy)
- Import/Export Parking (Legacy)
- Import/Export Shell (Legacy)

## Manual Installation

If the installer doesn't work, manually copy these files:

For Revit 2025:
- Copy Revit2025\ISPG.Conversion.dll to %APPDATA%\Autodesk\Revit\Addins\2025\
- Copy Revit2025\ISPG.Conversion.addin to %APPDATA%\Autodesk\Revit\Addins\2025\

For Revit 2027:
- Copy Revit2027\ISPG.Conversion.dll to %APPDATA%\Autodesk\Revit\Addins\2027\
- Copy Revit2027\ISPG.Conversion.addin to %APPDATA%\Autodesk\Revit\Addins\2027\

---
Built with GitHub Actions
