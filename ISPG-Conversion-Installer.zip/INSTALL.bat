@echo off
REM ISPG Conversion Tools - One-Click Installer
echo ================================================================
echo ISPG Conversion Tools - Installer
echo ================================================================
echo.
echo This installer supports Revit 2025 and Revit 2027
echo.

REM Check for Revit 2025
set REVIT2025_DIR=%APPDATA%\Autodesk\Revit\Addins\2025
if exist "%REVIT2025_DIR%" (
    echo Installing for Revit 2025...
    if not exist "%REVIT2025_DIR%" mkdir "%REVIT2025_DIR%"
    copy /Y "%~dp0Revit2025\ISPG.Conversion.dll" "%REVIT2025_DIR%\"
    copy /Y "%~dp0Revit2025\ISPG.Conversion.addin" "%REVIT2025_DIR%\"
    echo   - Revit 2025: INSTALLED
) else (
    echo   - Revit 2025: NOT FOUND (skipped)
)

echo.

REM Check for Revit 2027
set REVIT2027_DIR=%APPDATA%\Autodesk\Revit\Addins\2027
if exist "%REVIT2027_DIR%" (
    echo Installing for Revit 2027...
    if not exist "%REVIT2027_DIR%" mkdir "%REVIT2027_DIR%"
    copy /Y "%~dp0Revit2027\ISPG.Conversion.dll" "%REVIT2027_DIR%\"
    copy /Y "%~dp0Revit2027\ISPG.Conversion.addin" "%REVIT2027_DIR%\"
    echo   - Revit 2027: INSTALLED
) else (
    echo   - Revit 2027: NOT FOUND (skipped)
)

echo.
echo ================================================================
echo Installation Complete!
echo ================================================================
echo.
echo Next steps:
echo 1. Launch Revit (2025 or 2027)
echo 2. Look for 'ISPG' tab in the ribbon
echo 3. If the tab doesn't appear, check Add-Ins ^> External Tools
echo.
pause
